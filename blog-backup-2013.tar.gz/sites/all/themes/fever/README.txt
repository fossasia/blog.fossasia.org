$Id: README.txt,v 1.1 2010/08/05 07:51:20 antsin Exp $

Thank you for download Antsin Drupal theme - Fever. 

For more information on how to use this theme, please visit our online forums at www.antsin.com.

Note: registration is required to access user guide.